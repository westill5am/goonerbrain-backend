def scrape_motherless(query):
    return [{
        "title": f"Motherless Result for '{query}'",
        "url": "https://motherless.com",
        "preview": "",
        "source": "Motherless"
    }]