def scrape_erome(query):
    return [{
        "title": f"Erome Result for '{query}'",
        "url": "https://erome.com",
        "preview": "",
        "source": "Erome"
    }]