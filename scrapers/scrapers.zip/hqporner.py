def scrape_hqporner(query):
    return [{
        "title": f"HQPorner Result for '{query}'",
        "url": "https://hqporner.com",
        "preview": "",
        "source": "HQPorner"
    }]