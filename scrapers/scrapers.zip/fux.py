def scrape_fux(query):
    return [{
        "title": f"Fux Result for '{query}'",
        "url": "https://fux.com",
        "preview": "",
        "source": "Fux"
    }]