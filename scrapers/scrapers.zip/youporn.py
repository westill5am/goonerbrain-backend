def scrape_youporn(query):
    return [{
        "title": f"YouPorn Result for '{query}'",
        "url": "https://youporn.com",
        "preview": "",
        "source": "YouPorn"
    }]