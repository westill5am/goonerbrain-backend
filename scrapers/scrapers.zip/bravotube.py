def scrape_bravotube(query):
    return [{
        "title": f"BravoTube Result for '{query}'",
        "url": "https://bravotube.net",
        "preview": "",
        "source": "BravoTube"
    }]