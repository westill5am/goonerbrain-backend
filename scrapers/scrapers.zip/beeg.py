def scrape_beeg(query):
    return [{
        "title": f"Beeg Result for '{query}'",
        "url": "https://beeg.com",
        "preview": "",
        "source": "Beeg"
    }]