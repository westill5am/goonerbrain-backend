def scrape_xhamster(query):
    return [{
        "title": f"XHamster Result for '{query}'",
        "url": "https://xhamster.com",
        "preview": "",
        "source": "XHamster"
    }]