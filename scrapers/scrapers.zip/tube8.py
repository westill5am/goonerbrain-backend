def scrape_tube8(query):
    return [{
        "title": f"Tube8 Result for '{query}'",
        "url": "https://tube8.com",
        "preview": "",
        "source": "Tube8"
    }]